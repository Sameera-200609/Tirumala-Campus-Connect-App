document.addEventListener('DOMContentLoaded',()=>{
 const login=document.getElementById('loginForm');
 if(login){login.addEventListener('submit',e=>{e.preventDefault();window.location.href='dashboard.html';});}
 const lost=document.getElementById('lostForm');
 if(lost){lost.addEventListener('submit',e=>{e.preventDefault();document.getElementById('lostMsg').textContent='Report submitted successfully (demo).';});}
 const appointment=document.getElementById('appointmentForm');
 if(appointment){appointment.addEventListener('submit',e=>{e.preventDefault();document.getElementById('appointmentMsg').textContent='Appointment request submitted (demo).';});}
 const chat=document.getElementById('chat'), form=document.getElementById('chatForm'), input=document.getElementById('chatInput');
 if(form){form.addEventListener('submit',e=>{e.preventDefault();const q=input.value.trim();if(!q)return;chat.insertAdjacentHTML('beforeend',`<div class="message user">${escapeHtml(q)}</div>`);let answer='I can help with timetable, attendance, events, placements, lost & found, bus tracking and faculty appointments.';const l=q.toLowerCase();if(l.includes('attendance'))answer='You can view subject-wise attendance from the Attendance page.';else if(l.includes('timetable'))answer='Open Smart Timetable from the dashboard to view today’s classes.';else if(l.includes('placement'))answer='Open Placements to see career preparation categories.';else if(l.includes('event'))answer='Open Events to see campus activities and announcements.';setTimeout(()=>chat.insertAdjacentHTML('beforeend',`<div class="message bot">${answer}</div>`),250);input.value='';chat.scrollTop=chat.scrollHeight;});}
});
function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}
